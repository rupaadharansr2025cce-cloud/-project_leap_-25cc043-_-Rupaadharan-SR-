package com.example.project_leap_25cc043_rupaadharan;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectLeap25cc043RupaadharanApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjectLeap25cc043RupaadharanApplication.class, args);
	}

}
